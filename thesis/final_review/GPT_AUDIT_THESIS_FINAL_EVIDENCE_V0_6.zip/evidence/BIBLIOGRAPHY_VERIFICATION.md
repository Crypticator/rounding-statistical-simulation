# Bibliographie : sources vérifiées dans l'audit final (17 novembre 2026)

Ces sources vérifient les identités et le rôle général des références, **pas la priorité exhaustive** du travail de thèse.

1. Blackwell (1953), *Equivalent Comparisons of Experiments*, DOI 10.1214/aoms/1177729032, index bibliographique OpenAIRE : https://explore.openaire.eu/search/result?pid=10.1214%2Faoms%2F1177729032
2. Levin & Peres, avec contributions de Wilmer, *Markov Chains and Mixing Times*, 2e éd., page d'auteurs : https://pages.uoregon.edu/dlevin/MARKOV/
3. Regev (2010), CCC 191–204, notice DBLP : https://dblp.org/rec/conf/coco/Regev10 ; la notice porte « (Invited Survey) » qui n'apparaît pas dans la forme abrégée du manuscrit.
4. Banerjee, Peikert & Rosen, *Pseudorandom Functions and Lattices*, EUROCRYPT 2012, pp. 719–737, table éditeur Springer : https://link.springer.com/book/10.1007/978-3-642-29011-4
5. Sarkar & Singh, *On certain semigroups of transformations that preserve a partition*, arXiv 2006.04242 : https://arxiv.org/abs/2006.04242
6. Shoup (2006), *Sequences of Games*, version d'auteur : https://www.shoup.net/papers/games.pdf
7. Torgersen (1991), *Comparison of Statistical Experiments*, Cambridge University Press : https://www.cambridge.org/core/books/comparison-of-statistical-experiments/405F64D2A2FB3A4E6A1893C1C8A4A60B
8. Verine et al. (2024), AISTATS/PMLR 238:3367–3375 : https://proceedings.mlr.press/v238/verine24a.html
9. Block & Polyanskiy (2023), COLT/PMLR 195:228–273 : https://proceedings.mlr.press/v195/block23a.html
10. Van Rooyen & Williamson (2014), arXiv 1402.4884 : https://arxiv.org/abs/1402.4884
11. Mu, Pomatto, Strack & Tamuz (2021), *Econometrica* 89(1):475–506 : https://onlinelibrary.wiley.com/doi/10.3982/ECTA17548

**Champ :** attributs bibliographiques et rôles descriptifs. Aucun examen systématique de tous les travaux apparentés ni garantie d'absence de publication antérieure n'a été tenté.
