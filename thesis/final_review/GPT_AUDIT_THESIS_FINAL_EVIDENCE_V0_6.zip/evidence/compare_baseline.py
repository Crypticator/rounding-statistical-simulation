from pathlib import Path
from hashlib import sha256
import re,json,difflib
D=Path('/mnt/data/thesis_final_audit/MANUSCRIPT'); old=(D/'prior_reviews/APPROVED_BASELINE_V0_5_1.md').read_text(); new=(D/'THESIS_Rounding_Statistical_Simulation_v0_6.md').read_text()
items={}
for ch in range(2,11):
 pattern=rf'^# {ch} ';old_m=re.search(pattern,old,re.M);new_m=re.search(pattern,new,re.M)
 nextpattern=rf'^# {ch+1} ' if ch<10 else '^# Appendix A'
 old_next=re.search(nextpattern,old[old_m.start()+1:],re.M)
 newpattern='^# 11 ' if ch==10 else nextpattern
 new_next=re.search(newpattern,new[new_m.start()+1:],re.M)
 a=old[old_m.start():old_m.start()+1+old_next.start()]
 b=new[new_m.start():new_m.start()+1+new_next.start()]
 items[f'Chapter {ch}']=(a,b)
for label,nextpat in [('Appendix A','^# Appendix B'),('Appendix B','^# Appendix C'),('Appendix C','^# Appendix D'),('Appendix D','^# References')]:
 pat='^# '+label
 om=re.search(pat,old,re.M);nm=re.search(pat,new,re.M)
 oe=re.search(nextpat,old[om.start()+1:],re.M);ne=re.search(nextpat if label!='Appendix D' else '^# Appendix E',new[nm.start()+1:],re.M)
 items[label]=(old[om.start():om.start()+1+oe.start()],new[nm.start():nm.start()+1+ne.start()])
for label,pat,nxt in [('1.1–1.7','^## 1.1','^# 2 '),('Abstract','^## Abstract','^# 1 ')]:
 om=re.search(pat,old,re.M);nm=re.search(pat,new,re.M)
 if om and nm:
  oe=re.search(nxt,old[om.start()+1:],re.M); ne=re.search('^## 1.8' if label.startswith('1.') else nxt,new[nm.start()+1:],re.M)
  items[label]=(old[om.start():om.start()+1+oe.start()],new[nm.start():nm.start()+1+ne.start()])
items['References']=(old[old.index('# References'):],new[new.index('# References'):])
result={}
for k,(a,b) in items.items():
 na=''.join(a.split());nb=''.join(b.split());ok=na==nb
 result[k]={'same_after_whitespace':ok,'old_length':len(a),'new_length':len(b)}
 if not ok:result[k]['diff']='\n'.join(list(difflib.unified_diff(a.splitlines(),b.splitlines()))[:60])
print(json.dumps(result,indent=2,ensure_ascii=False))
Path('/mnt/data/thesis_final_audit/baseline_diff.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
