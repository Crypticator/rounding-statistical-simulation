#!/usr/bin/env python3
"""Fresh, source-independent spot checks of thesis v0.6 summary constants.
Only stdlib. Does not import any scientific routine or result from the manuscript.
Checks are finite corroborations, not universal proofs.
"""
from collections import defaultdict,Counter
from fractions import Fraction as F
from itertools import product
import json,math

NW={-1:1,0:2,1:1}

def tv(A,B):
    return sum(abs(A.get(k,F(0))-B.get(k,F(0))) for k in set(A)|set(B))/2

def repeated(L,Q):
    P=L*Q;k=2
    J=defaultdict(F)
    for z in range(P):
        for e1,e2 in product(NW,repeat=2):
            xs=((z+e1)%P,(z+e2)%P)
            y=tuple(x//Q for x in xs);b=tuple(x%2 for x in xs)
            J[(z,y,b)]+=F(NW[e1]*NW[e2],P*16)
    D=defaultdict(F);target=defaultdict(F); stateY=defaultdict(F)
    for (z,y,b),w in J.items():D[y]+=w;target[(y,b)]+=w;stateY[(z,y)]+=w
    Yall=list(product(range(L),repeat=2));Ball=list(product(range(2),repeat=2));
    fair={b:F(1,4) for b in Ball}
    post={y:{b:target[(y,b)]/D[y] for b in Ball} if D[y]>0 else fair for y in Yall}
    def is_constant(y):return y[0]==y[1]
    def mixed(y):return D[y]>0 and not is_constant(y)
    def laws(kind):
        if kind=='fair':return {y:fair for y in Yall}
        if kind=='post':return post
        if kind=='bal':return {y:(post[y] if mixed(y) else fair) for y in Yall}
        if kind=='sum':return {y:(post[y] if is_constant(y) or (mixed(y) and 3*L>=8*Q) else fair) for y in Yall}
        raise ValueError
    dists={}
    for kind in ['fair','bal','post','sum']:
        Ky=laws(kind)
        simstrong={(z,y,b):stateY[(z,y)]*Ky[y][b] for z in range(P) for y in Yall for b in Ball}
        simpublic={(y,b):D[y]*Ky[y][b] for y in Yall for b in Ball}
        nullsim={(y,b):Ky[y][b]/(L*L) for y in Yall for b in Ball}
        nulltarget={(y,b):F(1,4*L*L) for y in Yall for b in Ball}
        dists[kind]={
          'strong':str(tv(J,simstrong)),
          'public_real':str(tv(target,simpublic)),
          'public_null':str(tv(nulltarget,nullsim)),
          'public_sum':str(tv(target,simpublic)+tv(nulltarget,nullsim))}
    expected={'fair':('11/64','7/64','0','7/64'),
       'bal':('7/64','1/32','5/24','23/96'),
       'post':('51/416','0','17/78','17/78'),
       'sum':('77/416','5/64','1/104','73/832')}
    if L==4 and Q==4:
        for k,v in expected.items():assert tuple(dists[k].values())==v,(k,dists[k])
    # Independently compare weighted public infimum formula by actual conditional masses.
    for lam in [F(0),F(1,2),F(1),F(2),F(3*L,8*Q),F(L)*(1-F(3,4*Q))]:
        opt=sum(min(D[y],lam/(L*L))*tv(post[y],fair) for y in Yall)
        ac=F(Q,F(1))-F(3,4)
        ac/=P
        am=F(3,8*P);b=F(1,L*L)
        dc=F(1,8*Q-6); dm=F(5,12)
        rhs=L*min(ac,lam*b)*dc+2*L*min(am,lam*b)*dm
        assert opt==rhs,(L,Q,lam,opt,rhs)
    return dists

def matrix(P,m,n):
    rows=list(product(range(P),repeat=n));neg=lambda r:tuple((-x)%P for x in r)
    canon=lambda row:min(row,neg(row))
    clusters=defaultdict(lambda:[0,0])
    for mrows in product(rows,repeat=m):
        key=tuple(sorted(canon(r) for r in mrows));clusters[key][0]+=1
        ist=all(mrows[i][j]==mrows[i-1][j-1] for i in range(1,m) for j in range(1,n))
        if ist:clusters[key][1]+=1
    N=P**(m*n);T=P**(m+n-1)
    reach=sum(orbsize for orbsize,nt in clusters.values() if nt>0)
    sum_tv=sum(abs(F(orbsize,N)-F(nt,T)) for orbsize,nt in clusters.values())/2
    s=F(reach,N);a=F(T,N)
    if P==4 and m==3 and n==2:
        assert (s,sum_tv,a)==(F(501,1024),F(539,1024),F(1,16))
    return {'s_star':str(s),'delta_star':str(sum_tv),'alpha_exact':str(a),'orbits':len(clusters)}

def scalar(P,Q):
    L=P//Q; good=[]
    for a in range(P):
        for b in range(P):
            image={}
            valid=True
            for x in range(P):
                y=x//Q;w=((a*x+b)%P)//Q
                if y in image and image[y]!=w:valid=False;break
                image[y]=w
            model=(a==0) or (a==1 and b%Q==0) or (a==P-1 and b%Q==Q-1)
            assert valid==model,(P,Q,a,b,valid,model)
            if valid:good.append((a,b))
    return {'P':P,'Q':Q,'compatible_rows':len(good),'expected':P+2*L}

def singular_noise():
    # Direct joint enumeration for P=8,Q=2,c=4, eta=1/4.
    P,Q,c=8,2,4
    joint=defaultdict(F);zy=defaultdict(F);xw=defaultdict(F);xs=defaultdict(F)
    for z in range(P):
        for e,w in NW.items():
            x=(z+e)%P;y=x//Q;t=((c*x)%P)//Q
            mass=F(w,4*P)
            joint[(z,y,t)]+=mass;zy[(z,y)]+=mass;xw[(x,t)]+=mass;xs[x]+=mass
    fair_outputs=(0,2)
    sim={(z,y,t):zy[(z,y)]/2 for z in range(P) for y in range(P//Q) for t in fair_outputs}
    simstate=defaultdict(F);tarstate=defaultdict(F)
    for (z,y,t),v in sim.items():simstate[(z,t)]+=v
    for (z,y,t),v in joint.items():tarstate[(z,t)]+=v
    simX={(x,t):xs[x]/2 for x in range(P) for t in fair_outputs}
    result={'full_ZYW':str(tv(joint,sim)), 'state_ZW':str(tv(tarstate,simstate)),
      'raw_XW':str(tv(xw,simX)), 'expected_ZYW':str(F(1,2*Q))}
    assert result['full_ZYW']==result['expected_ZYW']=='1/4'
    assert result['state_ZW']=='0' and result['raw_XW']=='1/2'
    return result

if __name__=='__main__':
    report={'scalar':[scalar(4,2),scalar(6,3),scalar(8,4),scalar(12,2)],
      'matrix':[matrix(4,2,2),matrix(4,3,2)],
      'singular_noise':singular_noise(),
      'repeated_L4_Q4':repeated(4,4),
      'repeated_L16_Q6':repeated(16,6),
      'verification':'PASS; finite independent enumerations; exact rational arithmetic; no author-science imports'}
    print(json.dumps(report,indent=2))
