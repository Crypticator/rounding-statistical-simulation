from pathlib import Path
import re,json
s=Path('/mnt/data/thesis_final_audit/MANUSCRIPT/THESIS_Rounding_Statistical_Simulation_v0_6.md').read_text()
chunks=[s[s.index('## 1.8 '):s.index('# 2 ')],s[s.index('# 11 Conclusions'):s.index('# Appendix A')],s[s.index('# Appendix E'):s.index('# References')]]
add='\n'.join(chunks)
sections=sorted(set(re.findall(r'^## (\d+\.\d+)\b',s,re.M)))
res=re.findall(r'(?:\b(?:theorems?|corollaries?|propositions?|lemmas?)\s+)(\d+\.\d+)',add,re.I)
sec=re.findall(r'§\s*(\d+\.\d+)',add)
sec+=re.findall(r'\b[Ss]ection\s+(\d+\.\d+)',add)
num_chapters={str(i) for i in range(1,12)}
chapters=set(re.findall(r'\b[Cc]hapter\s+(\d+)\b',add))
missing_sec=sorted({a for a in sec if a not in sections})
# Extract numbered results from the main manuscript (not from new summary)
results=set(re.findall(r'\*\*(?:Theorem|Corollary|Proposition|Lemma)\s+(\d+\.\d+)\.',s))
missing_result=sorted({a for a in res if a not in results})
missing_chapter=sorted(chapters-num_chapters)
record={'section_refs_checked':len(set(sec)),'result_refs_checked':len(set(res)),
 'chapter_refs_checked':len(chapters),'missing_sections':missing_sec,'missing_results':missing_result,'missing_chapters':missing_chapter,
 'status':'PASS' if not (missing_sec or missing_result or missing_chapter) else 'FAIL',
 'scope':'New 1.8, Chapter 11, Appendix E; syntactic existence only'}
print(json.dumps(record,indent=2))
Path('/mnt/data/thesis_final_audit/evidence/new_crossref_results.json').write_text(json.dumps(record,indent=2))
